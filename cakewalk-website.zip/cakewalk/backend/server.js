/*
  THE CAKEWALK WITH TARUNA — Backend Server
  Node.js + Express + Twilio WhatsApp
  =============================================
*/

require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const path       = require('path');
const fs         = require('fs');
const twilio     = require('twilio');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── TWILIO SETUP ─────────────────────────────────
const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN
);

// ── MIDDLEWARE ───────────────────────────────────
app.use(cors());
app.use(express.json());

// Serve frontend static files
app.use(express.static(path.join(__dirname, '../frontend')));

// ── ORDERS DATABASE (JSON file) ──────────────────
const DB_PATH = path.join(__dirname, 'orders.json');

function loadOrders() {
  if (!fs.existsSync(DB_PATH)) return [];
  try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); }
  catch { return []; }
}

function saveOrder(order) {
  const orders = loadOrders();
  orders.push(order);
  fs.writeFileSync(DB_PATH, JSON.stringify(orders, null, 2));
}

// ── FORMAT WHATSAPP MESSAGE ──────────────────────
function formatMessage(data) {
  const dt = data.datetime
    ? new Date(data.datetime).toLocaleString('en-IN', {
        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
        hour: '2-digit', minute: '2-digit'
      })
    : 'Not specified';

  return [
    `🧁 *NEW ORDER — The Cakewalk*`,
    ``,
    `👤 *Customer:* ${data.customerName}`,
    `📞 *Phone:* ${data.customerPhone}`,
    ``,
    `🛍️ *Items:*`,
    data.orderItems,
    ``,
    `📅 *${data.preference}:* ${dt}`,
    data.notes ? `📝 *Notes:* ${data.notes}` : `📝 *Notes:* None`,
    ``,
    `— Sent via The Cakewalk website`
  ].join('\n');
}

// ── POST /api/order ──────────────────────────────
app.post('/api/order', async (req, res) => {
  const { customerName, customerPhone, orderItems, preference, datetime, notes } = req.body;

  // Validate
  if (!customerName || !customerPhone || !orderItems || !preference || !datetime) {
    return res.status(400).json({ success: false, message: 'Please fill all required fields.' });
  }

  const order = {
    id: Date.now().toString(),
    customerName,
    customerPhone,
    orderItems,
    preference,
    datetime,
    notes: notes || '',
    createdAt: new Date().toISOString()
  };

  // Save to local JSON backup
  try { saveOrder(order); }
  catch (e) { console.error('Failed to save order locally:', e.message); }

  // Send WhatsApp via Twilio
  try {
    await client.messages.create({
      from: `whatsapp:${process.env.TWILIO_WHATSAPP_FROM}`,
      to:   `whatsapp:+${process.env.BAKERY_PHONE}`,
      body: formatMessage(order)
    });

    console.log(`✅ Order from ${customerName} sent via WhatsApp.`);
    return res.json({ success: true, message: 'Order sent successfully!' });
  } catch (err) {
    console.error('Twilio error:', err.message);
    // Still return success — order is saved locally and frontend will open WhatsApp as fallback
    return res.status(500).json({ success: false, message: 'WhatsApp failed. Please try again or contact directly.' });
  }
});

// ── GET /api/orders (view all saved orders) ──────
app.get('/api/orders', (req, res) => {
  const secret = req.query.secret;
  if (secret !== process.env.ADMIN_SECRET) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  res.json(loadOrders());
});

// ── SERVE FRONTEND FOR ALL OTHER ROUTES ──────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// ── START SERVER ──────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🎂 The Cakewalk server running at http://localhost:${PORT}\n`);
});
